import json
import requests
import os
import boto3
import uuid
import sys

s3 = boto3.client('s3')
#s3resource = boto3.resource('s3')
currencies = [ 'STOCK_USD','STOCK_EUR','STOCK_CAD','STOCK_GBP','STOCK_CHF' ]
ApiUrl = 'https://query1.finance.yahoo.com/v7/finance/quote?lang=en-US&region=US&corsDomain=finance.yahoo.com&fields=symbol,regularMarketPrice&symbols='
BucketName = os.environ['OUTPUT_BUCKET']
TmpFileName = "/tmp/temp_stocks.json"
headers = {'User-Agent': 'My User Agent 1.0','From': 'youremail@domain.com'}

#s3.create_bucket(Bucket=BucketName,CreateBucketConfiguration={'LocationConstraint': 'eu-west-1'})

##trying linterdddssasda

def lambda_handler(event, context):
    for currency in currencies:
        #print(currency)
        ApiUrlWithStock = ApiUrl + os.environ[currency]
        #print(ApiUrlWithStock)
        FileName = currency + ".json"
        TempFile = open(TmpFileName, 'w')
        AllPrices = requests.get(ApiUrlWithStock, headers=headers)
        Response = AllPrices.json()
        list1 = (Response['quoteResponse'])['result']
        for i in range(0,len(list1)):
            Response_price = (Response['quoteResponse'])['result'][i]['regularMarketPrice']
            Response_symbol = (Response['quoteResponse'])['result'][i]['symbol']
            #print("%s,%s" % (Response_symbol, Response_price))
            TempFile.write("%s,%s\n" % (Response_symbol, Response_price))
        TempFile.close()   
        with open(TmpFileName, 'rb') as f: #otvori temp file
            s3.upload_fileobj(f, BucketName,FileName) #ulozi ho do bucketu
            #object_acl = s3resource.ObjectAcl(BucketName,FileName).put(ACL='public-read') #znova nastavi public permissions #testing

    return {
        'statusCode': 200
    }